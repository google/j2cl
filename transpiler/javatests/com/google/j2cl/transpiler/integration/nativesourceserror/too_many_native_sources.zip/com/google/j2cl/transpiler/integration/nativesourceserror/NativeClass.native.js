NativeClass.prototype.m_nativeInstanceMethod = function () {
  return "nativeInstanceMethod";
}

NativeClass.m_nativeStaticMethod = function() {
  return "nativeSaticMethod";
}